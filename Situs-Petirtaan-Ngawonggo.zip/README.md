# Menu Option
  - beranda
  - sejarah
  - icon
  - reservasi
  - letak

# Input Reservasi
Nama: Gesti
Jumlah orang: 15 orang
Asal : SMPN 01 Malang
Kepentingan: Edukasi
Kedatangan: 23 Januari 2023 12.00 WIB

# cp
IG : @situspatirtaanngawonggo
WA : 0812-4987-9428
